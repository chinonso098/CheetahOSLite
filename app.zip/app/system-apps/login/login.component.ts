/* eslint-disable @angular-eslint/prefer-standalone */
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { GeneralMenu } from 'src/app/shared/system-component/menu/menu.types';
import { AudioService } from 'src/app/shared/system-service/audio.services';
import { DefaultService } from 'src/app/shared/system-service/defaults.services';
import { ProcessIDService } from 'src/app/shared/system-service/process.id.service';
import { WindowService } from 'src/app/shared/system-service/window.service';
import { ProcessHandlerService } from 'src/app/shared/system-service/process.handler.service';
import { RunningProcessService } from 'src/app/shared/system-service/running.process.service';
import { SessionManagmentService } from 'src/app/shared/system-service/session.management.service';
import { SystemNotificationService } from 'src/app/shared/system-service/system.notification.service';
import { CommonFunctions } from 'src/app/system-files/common.functions';
import { Constants } from 'src/app/system-files/constants';
import { Process } from 'src/app/system-files/process';
import { ComponentType } from 'src/app/system-files/system.types';
import { LoginHelpers } from './login.helper';

//declare const WebScreensaver:any;

@Component({
  selector: 'cos-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  standalone:false,
})

export class LoginComponent implements OnInit, AfterViewInit {

  // ========================================================================
  // Dependencies
  // ========================================================================
  private _audioService!:AudioService;
  private _defaultService!:DefaultService;
  private _windowService!:WindowService;
  private _processIdService!:ProcessIDService;
  private _runningProcessService!:RunningProcessService;
  private _processHandlerService!:ProcessHandlerService;
  private _sessionManagmentService!:SessionManagmentService
  private _systemNotificationService!:SystemNotificationService;
  private _wss:HTMLVideoElement | undefined;

  // ========================================================================
  // Form + UI State
  // ========================================================================
  loginForm!: FormGroup;
  _formBuilder!:FormBuilder
  formCntrlName = 'loginInput';

  password = Constants.EMPTY_STRING;
  currentTime = Constants.EMPTY_STRING;
  currentDate = Constants.EMPTY_STRING;
  logInCounter = 0;

  authFormTimeoutId!: NodeJS.Timeout;
  lockScreenTimeoutId!: NodeJS.Timeout;
  slideShowIntervalId!: NodeJS.Timeout;

  showUserInfo = true;
  showPasswordEntry = true;
  showLoading = false;
  showFailedEntry = false;
  showRestartShutDown = false;
  showPowerMenu = false;
  isPowerMenuVisible = false;
  isScreenLocked = true;
  isUserLogedIn = false;
  isFirstLogIn = false;
  isScreenSaverEnabled = false;

  powerMenuStyle:Record<string, unknown> = {};
  powerMenuOption = Constants.POWER_MENU_OPTION;

  readonly cheetahLogonKey = Constants.CHEETAH_LOGON_KEY;
  readonly cheetahPwrKey = Constants.CHEETAH_PWR_KEY;

 // incorrectPassword = 'The password is incorrect. Try again.';
  incorrectPassword = 'The password is incorrect. Try 1234.';
  exitMessage = Constants.EMPTY_STRING;
  authForm = 'AuthenticationForm';
  currentDateTime = 'DateTime'; 
  viewOptions = Constants.EMPTY_STRING;

  // ========================================================================
  // Assets / Constants
  // ========================================================================
  cheetahUnlockAudio = `${Constants.AUDIO_BASE_PATH}cheetah_unlock.wav`;
  cheetahlockAudio = `${Constants.AUDIO_BASE_PATH}cheetah_lock.mp3`;
  cheetahlogOffAudio = `${Constants.AUDIO_BASE_PATH}cheetah_logoff.wav`;
  cheetahRestartAndShutDownAudio = `${Constants.AUDIO_BASE_PATH}cheetah_shutdown.wav`;

  video1 = `${Constants.SCREEN_SAVER_BASE_PATH}falling_leaves.mp4`;
  video2 = `${Constants.SCREEN_SAVER_BASE_PATH}gentle_moments.mp4`;
  video3 = `${Constants.SCREEN_SAVER_BASE_PATH}moon_light_ride.mp4`;
  video4 = `${Constants.SCREEN_SAVER_BASE_PATH}wishing_stars.mp4`;
  video5 = `${Constants.SCREEN_SAVER_BASE_PATH}cloud_timelapse.mp4`;

  userIcon = `${Constants.ACCT_IMAGE_BASE_PATH}default_user.png`;
  pwrBtnIcon = `${Constants.IMAGE_BASE_PATH}cheetah_power_shutdown.png`;
  loadingGif = `${Constants.GIF_BASE_PATH}cheetah_loading.gif`;

  readonly defaultPassWord = "1234";

  lockScreenBackgroundType = Constants.EMPTY_STRING;
  lockScreenBackgroundValue = Constants.EMPTY_STRING;
  menuData:GeneralMenu[] = [];

  // ========================================================================
  // Process metadata
  // ========================================================================
  hasWindow = false;
  icon = `${Constants.IMAGE_BASE_PATH}generic_program.png`;
  name = 'cheetah_authentication';
  processId = 0;
  type = ComponentType.System;
  displayName = Constants.EMPTY_STRING;
  

  // ========================================================================
  // Constructor / Setup wiring
  // ========================================================================
  constructor(runningProcessService:RunningProcessService, processIdService:ProcessIDService, audioService:AudioService, 
              formBuilder: FormBuilder, sessionManagmentService:SessionManagmentService, systemNotificationService:SystemNotificationService,
              defaultService:DefaultService, windowService:WindowService, processHandlerService:ProcessHandlerService){
    this._processIdService = processIdService;
    this.processId = this._processIdService.getNewProcessId();

    this._formBuilder = formBuilder;

    this._audioService = audioService;
    this._windowService = windowService
    this._defaultService = defaultService;
    this._processHandlerService = processHandlerService
    this._sessionManagmentService = sessionManagmentService;
    this._systemNotificationService = systemNotificationService;

    this._runningProcessService = runningProcessService;
    this._runningProcessService.addProcess(this.getComponentDetail());
    this._systemNotificationService.resetLockScreenTimeOutNotify.subscribe(() => { this.resetLockScreenTimeOut()});

    this._defaultService.defaultSettingsChangeNotify.subscribe((p) => {
      if(p === Constants.DEFAULT_LOCK_SCREEN_TIMEOUT){  this.resetLockScreenTimeOut(); }

      if(p === Constants.DEFAULT_LOCK_SCREEN_BACKGROUND){  this.getLockScreenBackgroundData(); }

      if(p === Constants.DEFAULT_SCREEN_SAVER_STATE){  this.syncAndHandleScreenSaver();  }
    })

    this._systemNotificationService.shutDownSystemNotify.subscribe(() => { 
      this.logInCounter = 0;
      this.shutDownOSFromDesktop();
    });

    this._systemNotificationService.restartSystemNotify.subscribe((p) => { 
      this.logInCounter = 0;
      if(p === Constants.RSTRT_ORDER_LOCK_SCREEN){
        this.restartOSFromDesktop()
      }
    });

    this._systemNotificationService.logOffNotify.subscribe(() => { 
      this.logInCounter = 0;
      this.logOffAndShowLockScreen();
    });

    this._systemNotificationService.lockScreenNotify.subscribe(() => { 
      this.lockScreen();
    });
  }

  // ========================================================================
  // Angular lifecycle
  // ========================================================================
  ngOnInit():void {
    this.getLockScreenBackgroundData();
    this.thingsToDoFirstOnInit();
    this.retrievePastSessionData();

    if(this.isUserLogedIn)
      this.showDesktop();
    else
      this.showLockScreen();
  }

  ngAfterViewInit(): void {
    const onlySyncScrnSvrState = true;

    this.setLockScreenBackground();
    this.syncAndHandleScreenSaver(onlySyncScrnSvrState);
  }

  // ========================================================================
  // Init helpers (forms / time / menu)
  // ========================================================================
  thingsToDoFirstOnInit():void{
    this.loginForm = this._formBuilder.nonNullable.group({
      loginInput: Constants.EMPTY_STRING,
    });

    this.viewOptions =  this.currentDateTime;
    const secondsDelay = [1000, 360000];  // Update time every second
    this.getTime(); // Set initial time
    this.getDate(); // Set initial Date

    setInterval(() => { this.getTime(); }, secondsDelay[0]); 
    setInterval(() => { this.getDate();  }, secondsDelay[1]); 

    this._systemNotificationService.showLockScreenNotify.next();
    this._systemNotificationService.setIsScreenLocked(this.isScreenLocked);
    this.getPowerMenuData();
  }

  getDate():void{
    this.currentDate = LoginHelpers.getDate();
  }

  getTime():void {
    this.currentTime = LoginHelpers.updateTime();
  }

  getPowerMenuData():void{
    this.menuData = [
      {icon:`${Constants.IMAGE_BASE_PATH}cheetah_power_shutdown.png`, label: 'Shut down', action: this.shutDownOSFromLockScreen.bind(this) },
      {icon:`${Constants.IMAGE_BASE_PATH}cheetah_restart.png`, label: 'Restart', action:this.restartOSFromLockScreen.bind(this)}
    ];
  }

  // ========================================================================
  // Input / click handlers (lock screen)
  // ========================================================================
  onKeyDown(evt:KeyboardEvent):void{
    if(evt.key === Constants.BLANK_SPACE){
      this.showAuthForm();
      this.updateScreenSaverParams();
    }
  }

  onLockScreenViewClick():void{
    this.showPowerMenu = false;
    this.showAuthForm();
    this.updateScreenSaverParams();
  }

  async onEnteringPassword(evt?:KeyboardEvent): Promise<void>{
    const secondsDelays = [2500, 3000]; //2.5 & 3 seconds
    if(evt?.key === "Enter"){
      const loginTxt = this.loginForm.value.loginInput as string;
      if(loginTxt === this.defaultPassWord){
        this.isUserLogedIn = true;
        this.showPasswordEntry = false;
        this.showLoading = true;
        this.logInCounter++;

        this.stopScreenSaver();
        await CommonFunctions.sleep(secondsDelays[0]);
        await this.showDesktop(); 
      }else{
        this.showPasswordEntry = false;
        this.showLoading = true;

        await CommonFunctions.sleep(secondsDelays[1]);
        this.showLoading = false;
        this.showFailedEntry = true;

        this.loginForm.controls[this.formCntrlName].setValue(null);
      }
    }
    this.resetAuthFormTimeOut();
  }

  onBtnClick():void{
    this.resetAuthFormState();
  }

  // ========================================================================
  // Auth form display + timeout
  // ========================================================================
  showAuthForm():void{
    this.viewOptions = this.authForm;
    LoginHelpers
    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(lockScreenElmnt){
      if(this.lockScreenBackgroundType === Constants.BACKGROUND_MIRROR){
        lockScreenElmnt.style.backdropFilter = 'blur(40px)';
        lockScreenElmnt.style.transition = 'backdrop-filter 0.4s ease';
      }
      this.startAuthFormTimeOut();
    }
  }

  startAuthFormTimeOut():void{
    const secondsDelay = 60000; //wait 1 min
    this.resetAuthFormTimeOutOnly();

    this.authFormTimeoutId = setTimeout(() => {
      this.loginForm.controls[this.formCntrlName].setValue(null);
      //console.log('startAuthFormTimeOut fired at:', new Date().toISOString());
      this.showDateTime();
    }, secondsDelay);
  }

  showDateTime():void{
    if(!this.isScreenLocked) return;

    this.viewOptions = this.currentDateTime;
    this.updateScreenSaverParams();

    if(this.isScreenSaverEnabled){
      if(this.isCurrentDateTimeVisibleOnLockScreen() && this.isScreenLocked  && this.logInCounter > 0)
        this.startScreenSaver();
    }

    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(lockScreenElmnt){
      lockScreenElmnt.style.backdropFilter = 'none';
    }
  }

  resetAuthFormTimeOut():void{
    clearTimeout(this.authFormTimeoutId);
    this.startAuthFormTimeOut();
  }

  resetAuthFormTimeOutOnly():void{
    // prevent overlapping timeouts
    if(this.authFormTimeoutId){
      clearTimeout(this.authFormTimeoutId);
    }
  }

  // ========================================================================
  // Desktop / lock screen transitions
  // ========================================================================
  async showDesktop(): Promise<void>{ 
    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(!lockScreenElmnt) return;

    lockScreenElmnt.style.zIndex = '-1';
    lockScreenElmnt.style.backdropFilter = 'none';

    this.isScreenLocked = false;
    this._systemNotificationService.showDesktopNotify.next();
    this._systemNotificationService.setIsScreenLocked(this.isScreenLocked);
    this.startLockScreenTimeOut();

    if(this.isUserLogedIn && this.isFirstLogIn)
      await this._audioService.play(this.cheetahUnlockAudio);

    this.resetAuthFormState();
    this.storeState(Constants.SIGNED_IN);
    this.stopSlideShow();
  }

  async showLockScreen(isShtDwnOrRstrt:boolean = false, chgBkgrnd:boolean = false):Promise<void>{
    this.viewOptions = (!isShtDwnOrRstrt)? this.currentDateTime : this.authForm;

    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(!lockScreenElmnt) return;

    lockScreenElmnt.style.zIndex = '6';
    lockScreenElmnt.style.backdropFilter = 'none';

    if(!isShtDwnOrRstrt && !this.isScreenLocked)
      await this._audioService.play(this.cheetahlockAudio);

    this.isScreenLocked = true;
    this.isFirstLogIn = true;
    this.loginForm.controls[this.formCntrlName].setValue(null);
    this._systemNotificationService.showLockScreenNotify.next();
    this._systemNotificationService.setIsScreenLocked(this.isScreenLocked);
    this.storeState(Constants.SIGNED_OUT);

    this.setLockScreenBackground(isShtDwnOrRstrt, chgBkgrnd);

    if(!isShtDwnOrRstrt && this.isScreenSaverEnabled){
      this.updateScreenSaverParams();
      this.startScreenSaver();
    }
  }

  async logOffAndShowLockScreen():Promise<void>{
    const isShtDwnOrRstrt:boolean = false, chgBkgrnd:boolean = false
    this.viewOptions = (!isShtDwnOrRstrt)? this.currentDateTime : this.authForm;

    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(!lockScreenElmnt) return;

    lockScreenElmnt.style.zIndex = '6';
    lockScreenElmnt.style.backdropFilter = 'none';

    if(!this.isScreenLocked)
      await this._audioService.play(this.cheetahlogOffAudio);

    this.isScreenLocked = true;
    this.isFirstLogIn = true;
    this.loginForm.controls[this.formCntrlName].setValue(null);
    this._systemNotificationService.showLockScreenNotify.next();
    this._systemNotificationService.setIsScreenLocked(this.isScreenLocked);
    this.storeState(Constants.SIGNED_OUT);

    this.setLockScreenBackground(isShtDwnOrRstrt, chgBkgrnd);
  }

  // ========================================================================
  // Lock screen timeout controls
  // ========================================================================
  startLockScreenTimeOut():void{
    if(this.isScreenLocked) return;

    const defaultTimeOut = Number(this._defaultService.getDefaultSetting(Constants.DEFAULT_LOCK_SCREEN_TIMEOUT).split(Constants.COLON)[1]);
    const secondsDelay = defaultTimeOut; 
    this.lockScreenTimeoutId = setTimeout(async () => { await this.showLockScreen(); }, secondsDelay);
  }

  lockScreen():void{
    clearTimeout(this.lockScreenTimeoutId);
    this.showLockScreen();
  }

  resetLockScreenTimeOut():void{
    if(!this.isScreenLocked){
      clearTimeout(this.lockScreenTimeoutId);
      this.startLockScreenTimeOut();
    }
  }

  // ========================================================================
  // Screen saver
  // ========================================================================
  syncAndHandleScreenSaver(onlySyncScrnSvrState:boolean = false):void{
    const screenSaverState = this._defaultService.getDefaultSetting(Constants.DEFAULT_SCREEN_SAVER_STATE);
    this.isScreenSaverEnabled = screenSaverState === Constants.ON ? true : false;

    if(onlySyncScrnSvrState) return;

    if(this.isScreenSaverEnabled){
      if(this.isCurrentDateTimeVisibleOnLockScreen() && this.isScreenLocked  && this.logInCounter > 0)
        this.startScreenSaver();
    }
    else
      this.stopScreenSaver();
  }

  startScreenSaver():void{
    const elRef = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    const videoList = [this.video1, this.video2, this.video3, this.video4, this.video5];
    const videoSelection = CommonFunctions.simpleRandomNumberGen(0, 4);
    const scrnSaverVideo = videoList[videoSelection];

    const videoScreenSaver = LoginHelpers.createVideoScreenSaver(elRef, scrnSaverVideo);
    this._wss = LoginHelpers.startWebScreenSaver(videoScreenSaver);
  }

  stopScreenSaver():void{
    if(this._wss)
      LoginHelpers.stopWebSceenSaver();
  }

  isCurrentDateTimeVisibleOnLockScreen():boolean{
    return (this.viewOptions === this.currentDateTime);
  }

  updateScreenSaverParams():void{
    LoginHelpers.updateIsCurrentDateTimeOnLogonForm(this.isCurrentDateTimeVisibleOnLockScreen());
    LoginHelpers.updateIsScreenLocked(this.isScreenLocked);
    LoginHelpers.updateLogInCounter(this.logInCounter);
  }

  // ========================================================================
  // Lock screen background / slideshow
  // ========================================================================
  getLockScreenBackgroundData():void{
    const defaultBkgrnd = this._defaultService.getDefaultSetting(Constants.DEFAULT_LOCK_SCREEN_BACKGROUND).split(Constants.COLON);
    this.lockScreenBackgroundType = defaultBkgrnd[0];
    this.lockScreenBackgroundValue = defaultBkgrnd[1];
  }

  setLockScreenBackground(isShtDwnOrRstrt:boolean  = false, chgBkgrnd:boolean = false):void{
    const styleClasses = ['lockscreen_background_mirror', 'lockscreen_background_solid_color', 'lockscreen_background_picture'];
    let activeClass = Constants.EMPTY_STRING;

    if(isShtDwnOrRstrt && chgBkgrnd){
      const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
      if(lockScreenElmnt)
        lockScreenElmnt.style.backgroundColor = (chgBkgrnd) ? '#0078d8' : Constants.EMPTY_STRING;

      return;
    }

    if(this.lockScreenBackgroundType === Constants.BACKGROUND_MIRROR){
      const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
      if(lockScreenElmnt){
        this.stopSlideShow();
        activeClass = styleClasses[0];
        this.setStyle(lockScreenElmnt, styleClasses, activeClass);
      }
    }

    if(this.lockScreenBackgroundType === Constants.BACKGROUND_SOLID_COLOR){
      const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
      if(lockScreenElmnt){
        this.stopSlideShow();
        activeClass = styleClasses[1];
        this.setStyle(lockScreenElmnt, styleClasses, activeClass);
        lockScreenElmnt.style.backgroundColor = this.lockScreenBackgroundValue;
      }
    }

    if(this.lockScreenBackgroundType === Constants.BACKGROUND_PICTURE){
      const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
      if(lockScreenElmnt){
        this.stopSlideShow();
        activeClass = styleClasses[2];
        this.setStyle(lockScreenElmnt, styleClasses, activeClass);
        lockScreenElmnt.style.backgroundImage = `url(${this.lockScreenBackgroundValue})`;
      }
    }

    if(this.lockScreenBackgroundType === Constants.BACKGROUND_SLIDE_SHOW){
      const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
      if(lockScreenElmnt){
        if(this.lockScreenBackgroundValue === Constants.BACKGROUND_SLIDE_SHOW_SOLID_COLOR){
          activeClass = styleClasses[1];
          this.setStyle(lockScreenElmnt, styleClasses, activeClass);
          this.startColorSlideShow(lockScreenElmnt)
        }else{
          activeClass = styleClasses[2];
          this.setStyle(lockScreenElmnt, styleClasses, activeClass);
          const contentSet = this.generateLockScreenPictureOptions();
          this.startPictureSlideShow(lockScreenElmnt, contentSet);
        }
      }
    }
  }

  setStyle(lockScreenElmnt: HTMLDivElement, styleClasses:string[], activeClass:string) {
    // 🧹 Reset previous inline styles
    CommonFunctions.resetInlineStyles(lockScreenElmnt);
    lockScreenElmnt.classList.remove(...styleClasses);
    lockScreenElmnt.classList.add(activeClass);
  }

  startPictureSlideShow(lockScreenElmnt: HTMLDivElement, contentSet:string[]) {
    const type = Constants.BACKGROUND_SLIDE_SHOW_PICTURE;
    this.startSlideShow(lockScreenElmnt, contentSet, type);
  }

  startColorSlideShow(lockScreenElmnt: HTMLDivElement) {
    const type = Constants.BACKGROUND_SLIDE_SHOW_SOLID_COLOR;
    const contentSet = this.generateColorOptions();
    this.startSlideShow(lockScreenElmnt, contentSet, type);
  }

  startSlideShow(lockScreenElmnt: HTMLDivElement, contentSet:string[], setType:string):void {
    this.slideShowIntervalId = CommonFunctions.startSlideShow(lockScreenElmnt, contentSet, setType);
  }

  stopSlideShow():void{
    CommonFunctions.stopSlideShow(this.slideShowIntervalId);
  }

  generateColorOptions():string[]{
    return Constants.LOCKSCREEN_DESKTOP_COLORS;
  }

  generateLockScreenPictureOptions():string[]{ 
    const options:string[] = [];
    const lockScreenImgPath = Constants.LOCK_SCREEN_IMAGE_BASE_PATH;
    const lockScreenImages = Constants.LOCKSCREEN_PICTURE_SET;

    lockScreenImages.forEach( imgName =>{ options.push(`${lockScreenImgPath}${imgName}`) });
    return options;
}

  // ========================================================================
  // Power menu UI handlers
  // ========================================================================
  async onPowerBtnClick(evt:MouseEvent): Promise<void>{
    evt.preventDefault();

    //The onLockScreenViewClick also listens for a click event. hence, i have to delay the response of onPowerBtnClick
    const delay = 10;
    await CommonFunctions.sleep(delay);

    if(!this.showPowerMenu && !this.isPowerMenuVisible){
      this.showPowerMenu = true;

      const powerBtnElmt = document.getElementById('powerBtnCntnr'); 
      if(powerBtnElmt){
        const pwrBtnRect = powerBtnElmt.getBoundingClientRect();
        powerBtnElmt.style.backgroundColor = Constants.EMPTY_STRING;

        this.powerMenuStyle = {
          'position':'absolute',
          'transform':`translate(${String(pwrBtnRect.x - 50)}px, ${String(pwrBtnRect.y - 352)}px)`,
          'z-index': 6,
        }
        this.isPowerMenuVisible = true;
        this.onPwdFieldRemoveFocus();
      }
    }else{
      this.showPowerMenu = false;
      this.isPowerMenuVisible = false;
    }    
  }

  onPowerBtnMouseEnter():void{
    const powerBtnElmt = document.getElementById('powerBtnCntnr') as HTMLDivElement; 
    if(!this.showPowerMenu){
      if(powerBtnElmt){
        powerBtnElmt.style.backgroundColor = '#b8b6b6';
      }
    }
  }

  onPowerBtnMouseLeave():void{
    const powerBtnElmt = document.getElementById('powerBtnCntnr') as HTMLDivElement; 
    if(powerBtnElmt){
      powerBtnElmt.style.backgroundColor = Constants.EMPTY_STRING;
    }
  }

  // ========================================================================
  // Power actions (shutdown / restart)
  // ========================================================================
  async shutDownOSFromLockScreen():Promise<void>{
    const delay = 6000; // 6 secs
    this.resetFields();
    this.changeLockScreenLogonPosition(40);
    this.hidePowerBtn();
    this.exitMessage = 'Shutting down';
    this.showRestartShutDown = true;
    await this._audioService.play(this.cheetahRestartAndShutDownAudio);

    this.shutDownRestartPrep(Constants.SYSTEM_SHUT_DOWN);
    this.storeState(Constants.SIGNED_OUT);
    this.storePwrState(Constants.SYSTEM_SHUT_DOWN);

    await CommonFunctions.sleep(delay);
    this.showPowerOnOffScreen();
  }

  async shutDownOSFromDesktop():Promise<void>{
    const isShutDown = true;
    const changeBkgrndColor = true;
    this.showLockScreen(isShutDown, changeBkgrndColor);
    await this.shutDownOSFromLockScreen();
    this.setLockScreenBackground();
  }

  async restartOSFromLockScreen():Promise<void>{
    const delay = 5500; // 5.5secs
    this.resetFields();
    this.changeLockScreenLogonPosition(40);
    this.hidePowerBtn();
    this.exitMessage = 'Restarting';
    this.showRestartShutDown = true;
    await this._audioService.play(this.cheetahRestartAndShutDownAudio);

    this.shutDownRestartPrep(Constants.SYSTEM_RESTART);
    this.storeState(Constants.SIGNED_OUT);
    this.storePwrState(Constants.SYSTEM_RESTART);

    await CommonFunctions.sleep(delay);
    this.showPowerOnOffScreen();
    this._systemNotificationService.restartSystemNotify.next(Constants.RSTRT_ORDER_PWR_ON_OFF_SCREEN);
  }

  async restartOSFromDesktop():Promise<void>{
    const isRestart = true;
    const changeBkgrndColor = true;
    this.showLockScreen(isRestart, changeBkgrndColor);
    await this.restartOSFromLockScreen();
    this.setLockScreenBackground();
  }

  shutDownRestartPrep(powerAction:string):void{
    CommonFunctions.prepareSystemForShutdownOrRestart(powerAction, this._systemNotificationService, 
      this._runningProcessService, this._processHandlerService, this._windowService, this._defaultService);
  }

  showPowerOnOffScreen():void{
    const powerOnOffElmnt = document.getElementById('powerOnOffCmpnt') as HTMLDivElement;
    if(powerOnOffElmnt){
      powerOnOffElmnt.style.zIndex = '7';
      powerOnOffElmnt.style.display = 'block';

      this.resetAuthFormState();
      this.changeLockScreenLogonPosition(25);
      this.showPowerBtn();
      this.storeState(Constants.SIGNED_OUT);

      this.viewOptions = this.currentDateTime;
      this.removeLockScreenBackDrop();
      this.resetAuthFormTimeOutOnly();
      // raise events to close opened apps
    }
  }

  // ========================================================================
  // Small DOM helpers (positioning / visibility / input focus)
  // ========================================================================
  changeLockScreenLogonPosition(top:number):void{
    const lsLogonElmnt = document.getElementById('lockscreen-logon-container') as HTMLDivElement; 
    if(lsLogonElmnt){
      lsLogonElmnt.style.top = `${top}%`;
    }
  }

  hidePowerBtn():void{
    const lsPwrBtn = document.getElementById('lockScreenPowerCntnr') as HTMLDivElement; 
    if(lsPwrBtn){
      lsPwrBtn.style.display = 'none';
    }
  }

  showPowerBtn():void{
    const lsPwrBtn = document.getElementById('lockScreenPowerCntnr') as HTMLDivElement; 
    if(lsPwrBtn){
      lsPwrBtn.style.display = 'block';
    }
  }

  removeLockScreenBackDrop():void{
    const lockScreenElmnt = document.getElementById('lockscreenCmpnt') as HTMLDivElement;
    if(lockScreenElmnt){
      lockScreenElmnt.style.backdropFilter = 'none';
    }
  }

  onPwdFieldClick():void{
    const lockScreenPwdElmnt = document.getElementById('lockScreenPwdTxtBox'); 
    if(lockScreenPwdElmnt){
      lockScreenPwdElmnt.style.backgroundColor = '#fff';
      lockScreenPwdElmnt.style.backdropFilter = 'none';
      lockScreenPwdElmnt.focus();
    }
  }

  onPwdFieldRemoveFocus():void{
    const lockScreenPwdElmnt = document.getElementById('lockScreenPwdTxtBox'); 
    if(lockScreenPwdElmnt){
      lockScreenPwdElmnt.style.backgroundColor = 'rgba(0, 0, 0, 0.3)';
      lockScreenPwdElmnt.style.backdropFilter = 'opacity(50)';
      lockScreenPwdElmnt.blur();
    }
  }

  // ========================================================================
  // UI state resets
  // ========================================================================
  resetAuthFormState():void{
    this.showUserInfo = true;
    this.showPasswordEntry = true;
    this.showLoading = false;
    this.showFailedEntry = false;
    this.showRestartShutDown = false;
  }

  resetFields():void{
    this.showUserInfo = false;
    this.showPasswordEntry = false;
    this.showLoading = false
    this.showFailedEntry = false;
  }

  // ========================================================================
  // Session storage helpers
  // ========================================================================
  storeState(state:string):void{
    this._sessionManagmentService.addSession(this.cheetahLogonKey, state);
  }

  storePwrState(state:string):void{
    this._sessionManagmentService.addSession(this.cheetahPwrKey, state);
  }
  
  retrievePastSessionData():void{
    const sessionData = this._sessionManagmentService.getSession(this.cheetahLogonKey) as string;
    console.log('login-psession:', sessionData);
    if(!sessionData || sessionData === Constants.SIGNED_OUT){
      this.isUserLogedIn = false;
      this.isFirstLogIn = true;
    }else{ 
      this.isUserLogedIn = true;
      this.isFirstLogIn = false;
    }
  }

  // ========================================================================
  // Process registration
  // ========================================================================
  private getComponentDetail():Process{
    return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type)
  }
}
