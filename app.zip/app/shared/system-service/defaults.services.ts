import { Injectable } from "@angular/core";

import { Constants } from "src/app/system-files/constants";
import { ProcessType } from "src/app/system-files/system.types";

import { Process } from "src/app/system-files/process";
import { Service } from "src/app/system-files/service";

import { BaseService } from "./base.service.interface";
import { ProcessIDService } from "./process.id.service";
import { RunningProcessService } from "./running.process.service";
import { SessionManagmentService } from "./session.management.service";
import { signal } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class DefaultService implements BaseService{

    private _processIdService!:ProcessIDService;
    private _runningProcessService!:RunningProcessService;
    private _sessionManagmentService!:SessionManagmentService;

    private _defaultSettingsMap!:Map<string, string>; 
    private readonly _defaultSettingServiceKey = Constants.CHEETAH_DEFAULT_SETTINGS_KEY;

    defaultSettingsChangeNotify = signal<string | null>(null, { equal: () => false });

    name = 'defaults_svc';
    icon = `${Constants.IMAGE_BASE_PATH}svc.png`;
    processId = 0;
    type = ProcessType.Cheetah;
    status  = Constants.SERVICES_STATE_RUNNING;
    hasWindow = false;
    description = 'handles tracking of usr choice';

    constructor(processIDService:ProcessIDService, runningProcessService:RunningProcessService, sessionManagmentService:SessionManagmentService) {
        this._processIdService = processIDService;
        this._runningProcessService = runningProcessService;
        this._sessionManagmentService = sessionManagmentService;

        this.processId = this._processIdService.getNewProcessId();
        this._runningProcessService.addProcess(this.getProcessDetail());
        this._runningProcessService.addService(this.getServiceDetail());

        this.retrievePastSessionData(this._defaultSettingServiceKey);
    }

    private initializeDefaultSettings(): void {

        this._defaultSettingsMap = new Map<string, string>([
            [Constants.DEFAULT_LOCK_SCREEN_TIMEOUT, Constants.DEFAULT_LOCK_SCREEN_TIMEOUT_VALUE],
            [Constants.DEFAULT_LOCK_SCREEN_BACKGROUND, Constants.DEFAULT_LOCK_SCREEN_BACKGROUND_VALUE],
            [Constants.DEFAULT_DESKTOP_BACKGROUND, Constants.DEFAULT_DESKTOP_BACKGROUND_VALUE],
            [Constants.DEFAULT_PREVIOUS_DESKTOP_PICTURE, Constants.DEFAULT_PREVIOUS_DESKTOP_PICTURE_VALUE],
            [Constants.DEFAULT_PREVIOUS_DESKTOP_SOLID_COLOR, Constants.DEFAULT_PREVIOUS_DESKTOP_SOLID_COLOR_VALUE],
            [Constants.DEFAULT_PREVIOUS_DESKTOP_DYNAMIC_IMG, Constants.DEFAULT_PREVIOUS_DESKTOP_DYNAMIC_IMG_VALUE],
            [Constants.DEFAULT_TASKBAR_COMBINATION, Constants.DEFAULT_TASKBAR_COMBINATION_VALUE],
            [Constants.DEFAULT_AUTO_HIDE_TASKBAR, Constants.DEFAULT_AUTO_HIDE_TASKBAR_VALUE],
            [Constants.DEFAULT_CLIP_BOARD_STATE, Constants.DEFAULT_CLIP_BOARD_STATE_VALUE],
            [Constants.DEFAULT_SCREEN_SAVER_STATE, Constants.DEFAULT_SCREEN_SAVER_STATE_VALUE],
            [Constants.DEFAULT_DISPLAY_DELETE_CONFIRMATION_DIALOG, Constants.DEFAULT_DISPLAY_DELETE_CONFIRMATION_DIALOG_VALUE],
            [Constants.DEFAULT_MOVE_TO_RECYCLE_BIN_ON_DELETE, Constants.DEFAULT_MOVE_TO_RECYCLE_BIN_ON_DELETE_VALUE],
            [Constants.DEFAULT_RESTORE_USER_OPENED_APPS, Constants.DEFAULT_RESTORE_USER_OPENED_APPS_VALUE],
            [Constants.DEFAULT_IS_USER_OPENED_APPS_RESTORED, Constants.DEFAULT_IS_USER_OPENED_APPS_RESTORED_VALUE]
        ]);

        this._sessionManagmentService.addMapBasedSession(this._defaultSettingServiceKey, this._defaultSettingsMap);
    }

    getDefaultSetting(key:string):string{

        if(this._defaultSettingsMap.has(key))
            return this._defaultSettingsMap.get(key) ?? Constants.EMPTY_STRING

        return Constants.EMPTY_STRING;
    }

    updateDefaultData(key:string, val:string, raiseEvent:boolean = true):void{
        this._defaultSettingsMap.set(key, val);
        this._sessionManagmentService.addMapBasedSession(this._defaultSettingServiceKey, this._defaultSettingsMap);
        
        if(raiseEvent)
            this.defaultSettingsChangeNotify.set(key);
    }

    private retrievePastSessionData(key:string):void{
        const sessionData = this._sessionManagmentService.getMapBasedSession(key) as Map<string, string>;
        //console.log(`${key} sessionData:`, sessionData);
        if(sessionData){
            if(key === this._defaultSettingServiceKey)
                this._defaultSettingsMap = sessionData;

            return;
        }

        this.initializeDefaultSettings();
    }

    public reset():void{
        this._defaultSettingsMap.clear();
        this.initializeDefaultSettings();
    }

    private getProcessDetail():Process{
        return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type)
    }

    private getServiceDetail():Service{
        return new Service(this.processId, this.name, this.icon, this.type, this.description, this.status)
    }
}
