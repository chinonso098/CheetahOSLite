import { Injectable } from "@angular/core";
import { Constants } from "src/app/system-files/constants";
import { ProcessType } from "src/app/system-files/system.types";
import { ProcessIDService } from "./process.id.service";
import { RunningProcessService } from "./running.process.service";
import { Process } from "src/app/system-files/process";
import { Service } from "src/app/system-files/service";
import { BaseService } from "./base.service.interface";
import { ComponentReferenceService } from "./component.reference.service";
import { UserNotificationType } from "src/app/system-files/common.enums";
import { DialogComponent } from "../system-component/dialog/dialog.component";
import { FileInfo } from "src/app/system-files/file.info";


@Injectable({
    providedIn: 'root'
})

export class UserNotificationService implements BaseService{

    private _runningProcessService!:RunningProcessService;
    private _processIdService!:ProcessIDService;
    private _componentReferenceService!:ComponentReferenceService;
    private dialogPid = 0;

    name = 'usr_notification_svc';
    icon = `${Constants.IMAGE_BASE_PATH}svc.png`;
    processId = 0;
    type = ProcessType.Background;
    status  = Constants.SERVICES_STATE_RUNNING;
    hasWindow = false;
    description = ' ';
    
    constructor(processIDService:ProcessIDService, runningProcessService:RunningProcessService, componentReferenceService:ComponentReferenceService){
        this._processIdService = processIDService;
        this._runningProcessService = runningProcessService;
        this._componentReferenceService = componentReferenceService;

        this.processId = this._processIdService.getNewProcessId();
        this._runningProcessService.addProcess(this.getProcessDetail());
        this._runningProcessService.addService(this.getServiceDetail());
    }

    private showDialogMsgBox(dialogMsgType:string, msg:string, title:string=Constants.EMPTY_STRING, uId:string = Constants.EMPTY_STRING):void{
        const componentRef = this._componentReferenceService.createComponent(DialogComponent);

        if(dialogMsgType === UserNotificationType.Error ||
            dialogMsgType === UserNotificationType.Info ||
            //dialogMsgType === UserNotificationType.Warning ||
            dialogMsgType === UserNotificationType.PowerOnOff ||
            dialogMsgType === UserNotificationType.FileTransferProgress||
            dialogMsgType === UserNotificationType.FileDeleteProgress
        ){
          componentRef.setInput('inputMsg', msg);
          componentRef.setInput('inputTitle', title);
          componentRef.setInput('inputCallingProcessUId', uId);
          componentRef.setInput('notificationType', dialogMsgType);
          this.dialogPid = componentRef.instance.processId;
        }
    }

    closeDialogMsgBox(pId:number):void{
        const process = this._runningProcessService.getProcess(pId); // if process exists, It is a  file Tranfser or Delete Dialog
        if(process)
            this._runningProcessService.closeProcessNotify.next(process);
        else
            this._componentReferenceService.removeComponent(pId);
    }

    showErrorNotification(msg:string, title:string){
       this.showDialogMsgBox(UserNotificationType.Error, msg, title);
    }

    showInfoNotification(msg:string,  uId:string = Constants.EMPTY_STRING){
        this.showDialogMsgBox(UserNotificationType.Info, msg, Constants.EMPTY_STRING, uId);
    }

    // showWarningNotification(msg:string, title:string){
    //     this.showDialogMsgBox(UserNotificationType.Warning, msg, title);
    // }

    async showWarningNotification(message: string, title: string, warningType:UserNotificationType = UserNotificationType.Warning, fileInfo?:FileInfo, uId:string = Constants.EMPTY_STRING): Promise<boolean> {
        return new Promise((resolve) => {
            const componentRef = this._componentReferenceService.createComponent(DialogComponent);
            componentRef.setInput('inputMsg', message);
            componentRef.setInput('inputTitle', title);
            componentRef.setInput('notificationType', warningType);
            componentRef.setInput('inputCallingProcessUId', uId);

            if(warningType === UserNotificationType.DeleteWarning || warningType === UserNotificationType.InUseWarning){
                if(!fileInfo){
                    console.error('File Information can not be undefined or null');
                    resolve(false);
                }
                componentRef.setInput('inputFile', fileInfo);
            }
            this.dialogPid = componentRef.instance.processId;
      
            // hook up close events
            componentRef.instance.confirm.subscribe(() => {
              resolve(true);
            });
      
            componentRef.instance.cancel.subscribe(() => {
              resolve(false);
            });
        });
    }
    

    showPowerOnOffNotification(msg:string){
        this.showDialogMsgBox(UserNotificationType.PowerOnOff, msg);
    }

    showFileTransferNotification(msg:string, title: string, type:UserNotificationType = UserNotificationType.FileTransferProgress){
        this.showDialogMsgBox(type, msg, title);
    }

    /**
     * All dialog box's PId can be gotten instantly, except WarningNotifiation, as result of it async nature.
     * it can only be retrieved after a selection is made.
     * @returns a proccess id for dialog box
     */
    getDialogPId():number{
        return this.dialogPid;
    }

    private getProcessDetail():Process{
        return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type)
    }

    private getServiceDetail():Service{
        return new Service(this.processId, this.name, this.icon, this.type, this.description, this.status)
    }
}