/* eslint-disable @angular-eslint/prefer-standalone */
import { Component, OnInit, AfterViewInit, OnDestroy, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { ComponentType } from 'src/app/system-files/system.types';
import { Constants } from "src/app/system-files/constants";
import { BaseComponent } from 'src/app/system-base/base/base.component.interface';
import { ProcessIDService } from 'src/app/shared/system-service/process.id.service';
import { Process } from 'src/app/system-files/process';
import { RunningProcessService } from 'src/app/shared/system-service/running.process.service';
import { AudioService } from 'src/app/shared/system-service/audio.services';
import { WindowService } from 'src/app/shared/system-service/window.service';
import { CommonFunctions } from 'src/app/system-files/common.functions';

@Component({
  selector:'cos-cheetah',
  templateUrl: './cheetah.component.html',
  styleUrls: ["./cheetah.component.css"],
  standalone:false,
})

export class CheetahComponent implements BaseComponent, OnInit, AfterViewInit, OnDestroy {

  // Reference to the tooltip element in the template. Using @ViewChild instead of
  // document.getElementById() keeps the lookup scoped to THIS component instance, so
  // multiple Cheetah dialogs could coexist without clashing over a shared DOM id.
  @ViewChild('cheetahAboutTooltip') private tooltipRef?:ElementRef<HTMLElement>;

  private _processIdService!:ProcessIDService;
  private _runningProcessService!:RunningProcessService;
  private _audioService!:AudioService;
  private _windowService!:WindowService;
  private _renderer:Renderer2;

  // Timer handles. Tracked so they can be cancelled on destroy (and before re-starting),
  // preventing leaked timers and callbacks that run against an already torn-down view.
  private infoMessageTimeOutId?:NodeJS.Timeout;
  private fancyLetterIntervalId?:ReturnType<typeof setInterval>;

  isDialog = true;
  isVisible = false;

  hasWindow = false;
  icon = `${Constants.IMAGE_BASE_PATH}cheetah.png`;
  cheetahIcon = `${Constants.IMAGE_BASE_PATH}cheetah-midsprint-dash.jpg`;
  processId = 0;
  type = ComponentType.System;
  displayName = 'CheetahOS';
  name = 'cheetah';

  // Single source of truth for the OS version, reused by the header and the info tooltip.
  private readonly osVersion = '4.10.02';
  version = `Version: ${this.osVersion}`;
  year = `\u00A9 ${new Date().getFullYear()}`;
  infoMessage = Constants.EMPTY_STRING;

  readonly defaultAudio = `${Constants.AUDIO_BASE_PATH}about_cheetah.mp3`;

  constructor(processIdService:ProcessIDService,  runningProcessService:RunningProcessService, audioService:AudioService, windowService:WindowService, renderer:Renderer2) { 
    this._processIdService = processIdService;
    this._runningProcessService = runningProcessService;
    this._audioService = audioService;
    this._windowService = windowService;
    this._renderer = renderer;

    this.processId = this._processIdService.getNewProcessId();
    this._runningProcessService.addProcess(this.getComponentDetail());
  }

  async ngOnInit(): Promise<void> {
    const delay = 10; //10ms
    await CommonFunctions.sleep(delay)
    await this._audioService.play(this.defaultAudio);
  }

   async ngAfterViewInit(): Promise<void> {    
    await CommonFunctions.sleep((10)); //delay of 10ms
    this.getInfoMessage();
  }

  // Clean up any outstanding timers so nothing fires after the component is destroyed
  // (prevents leaked timers and callbacks touching a view that no longer exists).
  ngOnDestroy(): void {
    clearTimeout(this.infoMessageTimeOutId);
    clearInterval(this.fancyLetterIntervalId);
  }

  getInfoMessage():void{
    this.infoMessage =`
CheetahOS
Version ${this.osVersion}
Copyright\u00A9 Chinonso098 2022 - ${new Date().getFullYear()}

Windows 10 icons & audio files Microsoft Corporation\u00A9. 
Windows \u2122 is a registered trademark of Microsoft Corporation.
Other trademarks and logos are property of their respective owners
    `
  }

  onMouseEnter1():void{
    // Hovering the tooltip itself should only keep an already-visible tooltip open.
    // If it's hidden, do nothing (don't re-show it just because the cursor grazed
    // the now-invisible tooltip region). The pending-hide cancellation happens inside
    // onMouseEnter so both enter paths share the same logic.
    const showFancyLetters = false;
    if(!this.isVisible)
        return;

    this.onMouseEnter(showFancyLetters);
  }

  onMouseEnter(showFancyLetters = true):void{
    // Cancel any hide that was scheduled by a previous onMouseLeave. Without this,
    // re-entering the icon (or cursor jitter on its edge) leaves a stale 3s timer
    // running that later fires and hides the tooltip "as soon as" the mouse moves away.
    clearTimeout(this.infoMessageTimeOutId);

    const aboutToolTip = this.tooltipRef?.nativeElement;
    if(aboutToolTip){
      this._renderer.setStyle(aboutToolTip, 'zIndex', '3');
      this._renderer.setStyle(aboutToolTip, 'opacity', '1');
      this._renderer.setStyle(aboutToolTip, 'transition', 'opacity 0.5s ease');
    }
    this.isVisible = true;

    if(showFancyLetters)
      this.fancyLetterEffect();
  }

   onMouseLeave():void{
    // Clear any previously scheduled hide first so timers can't stack up; otherwise
    // an earlier timer could still fire and hide the tooltip unexpectedly.
    clearTimeout(this.infoMessageTimeOutId);

    const delay = 3000; // wait 3 sec
    const aboutToolTip = this.tooltipRef?.nativeElement;

    this.infoMessageTimeOutId = setTimeout(() => {
      if(aboutToolTip){
        this._renderer.setStyle(aboutToolTip, 'zIndex', '-1');
        this._renderer.setStyle(aboutToolTip, 'opacity', '0');
        this._renderer.setStyle(aboutToolTip, 'transition', 'opacity 0.75s ease 1');
      }
      this.isVisible = false;
    }, delay); 
  }

  fancyLetterEffect(): void {
    // Cancel any in-flight animation so rapid re-hovers don't spawn competing
    // intervals that fight over `displayName` and cause flicker.
    clearInterval(this.fancyLetterIntervalId);

    const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const text = 'CheetahOS';
    const delay = 50;
    let counter = 0;

    this.fancyLetterIntervalId = setInterval(() => {
      let displayed = Constants.EMPTY_STRING;

      for (let i = 0; i < text.length; i++) {
        if (i < counter) {
          displayed += text[i];
        } else {
          const randomIndex = Math.floor(Math.random() * LETTERS.length);
          displayed += LETTERS[randomIndex];
        }
      }

      this.displayName = displayed;
      counter += 0.5;

      if (counter > text.length) {
        clearInterval(this.fancyLetterIntervalId);
      }
    }, delay);
  }


  focusWindow(evt?:MouseEvent):void{
    evt?.stopPropagation();

    if(this._windowService.getProcessWindowIDWithHighestZIndex() === this.processId) return;
    this._windowService.focusOnCurrentProcessWindowNotify.next(this.processId);
  }

  private getComponentDetail():Process{
    return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type);
  }
}