import { Component, ElementRef, OnDestroy, OnInit, AfterViewInit, ViewChild, Input } from '@angular/core';
import { ProcessIDService } from 'src/app/shared/system-service/process.id.service';
import { RunningProcessService } from 'src/app/shared/system-service/running.process.service';
import { ScriptService } from 'src/app/shared/system-service/script.services';
import { ProcessHandlerService } from 'src/app/shared/system-service/process.handler.service';
import { WindowService } from 'src/app/shared/system-service/window.service';
import { BaseComponent } from 'src/app/system-base/base/base.component.interface';
import { Constants } from 'src/app/system-files/constants';
import { Process } from 'src/app/system-files/process';
import { ComponentType } from 'src/app/system-files/system.types';
import { Boid } from './boid';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppState } from 'src/app/system-files/state/state.interface';
import { SessionManagmentService } from 'src/app/shared/system-service/session.management.service';
import { TaskBarPreviewImage } from 'src/app/system-apps/taskbarpreview/taskbar.preview';

declare const p5:any;

@Component({
  selector: 'cos-boids',
  templateUrl: './boids.component.html',
  styleUrls: ['./boids.component.css'],
  // eslint-disable-next-line @angular-eslint/prefer-standalone
  standalone:false,
})
export class BoidsComponent implements BaseComponent, OnInit, OnDestroy, AfterViewInit {
  @ViewChild('boidCanvas', { static: true }) boidCanvas!: ElementRef;
  @Input() priorUId = Constants.EMPTY_STRING;
  
  private _windowService!:WindowService;
  private _scriptService!:ScriptService;
  private _processIdService!:ProcessIDService;
  private _processHandlerService!:ProcessHandlerService;
  private _runningProcessService!:RunningProcessService;
  private _sessionManagmentService!:SessionManagmentService;

  private SECONDS_DELAY = 1000;
  private _appState!:AppState;
  private p5Instance: any;
  private _intervalId: any;
  flocks: Boid[] = [];

  params = {
    align: 1.2,
    cohesion: 1.5,
    separation: 1.8
  };

  form!:FormGroup;
  sliders = ['align', 'cohesion', 'separation'];

  name= 'boids';
  hasWindow = true;
  isMaximizable=false;
  icon = `${Constants.IMAGE_BASE_PATH}bird_oid.png`;
  processId = 0;
  type = ComponentType.User;
  displayName = 'Boids';


  constructor(processIdService:ProcessIDService, runningProcessService:RunningProcessService,  scriptService: ScriptService, 
              windowService:WindowService, triggerProcessService:ProcessHandlerService, private fb: FormBuilder,
              sessionManagmentService:SessionManagmentService) { 
                
    this._processIdService = processIdService;
    this._scriptService = scriptService;
    this._windowService = windowService;
    this._processHandlerService = triggerProcessService;
    this._sessionManagmentService = sessionManagmentService;

    this.processId = this._processIdService.getNewProcessId();
    this._runningProcessService = runningProcessService;
    this._runningProcessService.addProcess(this.getComponentDetail());
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      align: [1.2],
      cohesion: [1.5],
      separation: [1.4]
    });

    this._scriptService.loadScript("P5JS","osdrive/Cheetah/System/P5JS/p5.min.js").then(()=>{
      console.log('p5 loaded');
    });

    this.retrievePastSessionData();
  }

  ngAfterViewInit():void{
    const delay = 500; //500ms
    setTimeout(() => {
      this.p5Instance = new p5(this.sketch.bind(this), this.boidCanvas.nativeElement);
    }, delay);

    this.updateComponentImg();
  }

  ngOnDestroy(): void {
    if (this.p5Instance) {
      this.p5Instance.remove();
    }

    if (this._intervalId) {
      clearInterval(this._intervalId);
    }

    
  }

  captureComponentImg():void{
    const htmlImg =  this.captureCanvasStill();

    const cmpntImg:TaskBarPreviewImage = {
      pId: this.processId,
      appName: this.name,
      displayName: this.name,
      icon : this.icon,
      defaultIcon: this.icon,
      imageData: htmlImg
    }
    
    this._windowService.addProcessPreviewImage(this.name, cmpntImg);
  }

  sketch(p: any) {
    const boidCntnr = document.getElementById('boidCntnr');
    p.setup = () => {
      p.createCanvas(boidCntnr?.offsetWidth, boidCntnr?.offsetHeight);

      for (let i = 0; i < 100; i++) {
        this.flocks.push(new Boid(p));
      }
    };

    p.draw = () => {
      p.background('#393e46');
      const params = this.form.value;

      for (const boid of this.flocks) {
        boid.edges();
        boid.behavior(this.flocks, params);
        boid.update();
        boid.draw();
      }
    };

    p.windowResized = () => {
      p.resizeCanvas(boidCntnr?.offsetWidth, boidCntnr?.offsetHeight);
    };
  }

  public captureCanvasStill(): string  {
    const canvasElemnt = document.getElementById("defaultCanvas0") as HTMLCanvasElement;
    if (!canvasElemnt) return Constants.EMPTY_STRING;

    return canvasElemnt.toDataURL("image/png");
  }

  updateComponentImg():void{
    this._intervalId = setInterval(() => {
        this.captureComponentImg()
    }, this.SECONDS_DELAY);
  }


  focusWindow(evt?:MouseEvent):void{
    evt?.stopPropagation();

    if(this._windowService.getProcessWindowIDWithHighestZIndex() === this.processId) return;

    this._windowService.focusOnCurrentProcessWindowNotify.next(this.processId);
  }
  
  storeAppState(app_data:unknown):void{
    const uId = `${this.name}-${this.processId}`;
    this._appState = {
      pId: this.processId,
      appData: app_data as string,
      appName: this.name,
      uId: uId,
      window: {appName:'', pId:0, leftPx:0, topPx:0, heightPx:0, widthPx:0, zIndex:0, isVisible:true}
    }
    this._sessionManagmentService.addAppSession(uId, this._appState);
  }
  
  retrievePastSessionData():void{
    const appSessionData = this._sessionManagmentService.getAppSession(this.priorUId);
    if(appSessionData !== null && appSessionData.appData !== Constants.EMPTY_STRING){
      //
    }
  }
  
  private getComponentDetail():Process{
    return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type)
  }
}


