import { ElementRef, Renderer2 } from "@angular/core";
import { Constants } from "src/app/system-files/constants";
import { WindowConstants } from "./window.constants";


/**
 * Per-window styling / silhouette helper.
 *
 * Previously this file exported a `namespace` containing module-level mutable
 * `state` (renderer, glassPaneContainer, glass-pane id, left/top, etc.). That
 * design was effectively a singleton: every window instance wrote into the
 * same `state`, so whichever window most recently called `updateState` won.
 * That caused several latent bugs:
 *   - showSilhouette / positionSilhouette / hideSilhouette / removeSilhouette
 *     all read `state.uniqueGlassPaneId`, so they would operate on the wrong
 *     window's glass-pane after another window updated the shared state.
 *   - removeSilhouette could remove a sibling window's pane on close,
 *     leaving DOM orphans.
 *   - A retained Renderer2 reference in module state prevented GC.
 *
 * The class form below moves that state to instance fields, so each window
 * owns its own helper and its calls are correctly scoped.
 *
 * `applyStyle` and `createSilhouette` are stateless — kept as `static` methods
 * so existing call sites that don't need instance state don't have to change.
 */
export class WindowStyleHelper {

  // ────────────────────────────────────────────────────────────────────────
  // Per-instance state (replaces the former module-level `state` object)
  // ────────────────────────────────────────────────────────────────────────
  private glassPaneContainer: ElementRef<HTMLElement> | null = null;
  private renderer: Renderer2 | null = null;
  private windowLeftPx = 0;
  private windowTopPx = 0;
  private windowHeightPx = 0;
  private windowWidthPx = 0;
  private uniqueGlassPaneId: string = Constants.EMPTY_STRING;

  /**
   * Partial update: only the fields present in `patch` are written. Numeric
   * fields fall back to 0 when given a non-finite value (NaN/Infinity), and
   * nullable refs collapse `undefined` to `null` for predictable type narrowing.
   */
  updateState(patch: {
    glassPaneContainer?: ElementRef<HTMLElement> | null;
    renderer?: Renderer2 | null;
    windowLeftPx?: number;
    windowTopPx?: number;
    windowHeightPx?: number;
    windowWidthPx?: number;
    uniqueGlassPaneId?: string;
  }): void {
    if (patch.glassPaneContainer !== undefined) this.glassPaneContainer = patch.glassPaneContainer ?? null;
    if (patch.renderer !== undefined) this.renderer = patch.renderer ?? null;

    if (patch.windowLeftPx !== undefined)   this.windowLeftPx   = Number.isFinite(patch.windowLeftPx)   ? patch.windowLeftPx   : 0;
    if (patch.windowTopPx !== undefined)    this.windowTopPx    = Number.isFinite(patch.windowTopPx)    ? patch.windowTopPx    : 0;
    if (patch.windowHeightPx !== undefined) this.windowHeightPx = Number.isFinite(patch.windowHeightPx) ? patch.windowHeightPx : 0;
    if (patch.windowWidthPx !== undefined)  this.windowWidthPx  = Number.isFinite(patch.windowWidthPx)  ? patch.windowWidthPx  : 0;

    if (patch.uniqueGlassPaneId !== undefined) this.uniqueGlassPaneId = patch.uniqueGlassPaneId ?? Constants.EMPTY_STRING;
  }


  // ────────────────────────────────────────────────────────────────────────
  // Stateless helpers (no per-window state required)
  // ────────────────────────────────────────────────────────────────────────

  /**
   * Build the inline-style object bound to a window via `[ngStyle]`. Pure: it
   * doesn't read or write any helper state, so it stays static.
   */
  static applyStyle(inputStyle: Record<string, unknown>, windowLeftPx: number, windowTopPx: number,
    zIndex: number, opacity: number, isVisible: boolean = true): Record<string, unknown> {

    return {
      ...inputStyle,
      left: `${windowLeftPx}px`,
      top: `${windowTopPx}px`,
      transform: isVisible ? 'translate(0, 0)' : 'translate(0, 0) scale(1)',
      'z-index': zIndex,
      opacity
    };
  }

  /**
   * Create and append the (initially hidden) glass-pane element used as the
   * window's silhouette. Pure with respect to helper state — caller passes
   * everything in.
   */
  static createSilhouette(uniqueGlassPaneId: string, renderer: Renderer2,
    glassPaneContainer: ElementRef<HTMLElement>, windowHeightPx: number,
    windowWidthPx: number): ElementRef<HTMLElement> {

    const glassPane = renderer.createElement('div');

    glassPane.setAttribute('id', uniqueGlassPaneId);
    glassPane.style.transform = 'translate(0, 0)';
    glassPane.style.height = `${windowHeightPx}px`;
    glassPane.style.width = `${windowWidthPx}px`;

    glassPane.style.zIndex = String(WindowConstants.HIDDEN_Z_INDEX);
    glassPane.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    glassPane.style.backdropFilter = 'blur(2px)';
    glassPane.style.display = 'none';

    renderer.appendChild(glassPaneContainer.nativeElement, glassPane);
    return glassPaneContainer;
  }


  // ────────────────────────────────────────────────────────────────────────
  // Stateful silhouette / glass-pane operations.
  //   These all rely on `this.uniqueGlassPaneId`, `this.windowLeftPx/TopPx`,
  //   and `this.renderer/glassPaneContainer` — i.e. exactly the values that
  //   used to race in the singleton design.
  // ────────────────────────────────────────────────────────────────────────

  showSilhouette(): void {
    this.showGlassPaneContainer();

    const glassPane = document.getElementById(this.uniqueGlassPaneId) as HTMLDivElement | null;
    if (!glassPane) return;

    glassPane.style.display = 'block';
    glassPane.style.zIndex = String(WindowConstants.MIN_Z_INDEX);
    this.positionSilhouette();
  }

  positionSilhouette(): void {
    const glassPane = document.getElementById(this.uniqueGlassPaneId) as HTMLDivElement | null;
    if (!glassPane) return;

    glassPane.style.position = 'absolute';
    glassPane.style.left = `${this.windowLeftPx}px`;
    glassPane.style.top = `${this.windowTopPx}px`;
    glassPane.style.transform = 'translate(0px, 0px)';
  }

  showGlassPaneContainer(): void {
    if (!this.renderer || !this.glassPaneContainer) return;
    this.renderer.setStyle(this.glassPaneContainer.nativeElement, 'display', 'block');
  }

  hideSilhouette(): void {
    this.hideGlassPaneContainer();

    const glassPane = document.getElementById(this.uniqueGlassPaneId) as HTMLDivElement | null;
    if (!glassPane) return;

    glassPane.style.display = 'none';
    glassPane.style.zIndex = String(WindowConstants.HIDDEN_Z_INDEX);
  }

  hideGlassPaneContainer(): void {
    if (!this.renderer || !this.glassPaneContainer) return;
    this.renderer.setStyle(this.glassPaneContainer.nativeElement, 'display', 'none');
  }

  removeSilhouette(): void {
    const glassPane = document.getElementById(this.uniqueGlassPaneId) as HTMLDivElement | null;
    if (!glassPane) return;

    glassPane.remove();
  }

  syncSilhouetteSize(): void {
    const glassPane = document.getElementById(this.uniqueGlassPaneId) as HTMLDivElement | null;
    if (!glassPane) return;

    glassPane.style.width = `${this.windowWidthPx}px`;
    glassPane.style.height = `${this.windowHeightPx}px`;
  }
}