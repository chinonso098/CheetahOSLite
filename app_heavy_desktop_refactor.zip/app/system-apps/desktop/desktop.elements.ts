import { ElementRef } from "@angular/core";

/**
 * §1.4 — Strongly-typed bundle of the desktop's *singleton* DOM
 * elements (those that appear exactly once in the desktop template).
 *
 * Background: before this refactor, every handler and helper that
 * needed access to the desktop root, the icon grid, the clone
 * container, the multi-select pane, or the invalid-chars tooltip
 * looked them up by id with `document.getElementById(...)`.  That
 * scattered the same id strings across ~17 call sites in 6 files and
 * coupled component-scoped code to the global document.
 *
 * Now the `DesktopComponent` owns a `@ViewChild` for each singleton
 * and passes this bundle into every handler that needs DOM access.
 * Handlers store the bundle and dereference `nativeElement` on demand.
 * Pure helpers (which by §1.1.5 cannot inject Angular primitives)
 * receive the specific `HTMLElement` they need as a function argument.
 *
 * Note on `static: true`:
 *   All five elements live at the top level of the template — none of
 *   them are nested inside a structural directive (`*ngIf`, `@if`,
 *   `*ngFor`).  That means they are present in the view tree at the
 *   moment `ngOnInit` runs, and `@ViewChild(..., { static: true })`
 *   populates them in time for the existing `ngOnInit` wiring code
 *   (which is where the handlers get their `init(...)` calls).
 *
 * Note on naming:
 *   The legacy id `vantaCntnr` is preserved as the public field name
 *   so the migration is a 1:1 textual replacement at the call sites.
 *   A future naming pass (§1.6) may rename to `desktopRoot` once the
 *   Vanta-coupled wording is no longer accurate.
 */
export interface DesktopRootElements {
    /** `<main id="vantaCntnr">` — the desktop root that hosts the Vanta canvas. */
    vantaCntnr: ElementRef<HTMLElement>;
    /** `<ol id="desktopIcon_ol">` — the CSS-grid container for the icon tiles. */
    desktopIconOl: ElementRef<HTMLElement>;
    /** `<div id="desktopIcon_clone_cntnr">` — off-screen scratch for the drag-image clones. */
    desktopIconCloneCntnr: ElementRef<HTMLElement>;
    /** `<div id="dskTopMultiSelectPane">` — the rubber-band selection rectangle. */
    multiSelectPane: ElementRef<HTMLElement>;
    /** `<div id="invalidChars">` — the rename-textbox tooltip shown when illegal characters are typed. */
    invalidCharsToolTip: ElementRef<HTMLElement>;
}
