// appName tag carried on InformationUpdate so that only the originating terminal
// picks up live progress updates routed through SystemNotificationService. The
// command's unique id is used as the routing key (carried in InformationUpdate.pId).
// Producer (TerminalCommandProcessor) and consumer (TerminalComponent) share this.
export const TERMINAL_OUTPUT_APP_NAME = 'terminalOutput';

export class TerminalCommand {
    private static _nextCommandID = 1000;
    private _command: string;
    private _responseCode:number;
    private _commandOutput: string;
    private _commandID: number;

    constructor(cmd:string, respCode = 0, cmdOutput:string ){
        this._command = cmd;
        this._responseCode = respCode;
        this._commandOutput = cmdOutput;
        this._commandID = this.generateCommandID();
    }

    get getCommand(){
        return this._command;
    }
    set setCommand(cmd:string){
         this._command = cmd;
    }

    get getResponseCode(){
        return this._responseCode;
    }
    set setResponseCode(respCode:number){
        this._responseCode= respCode
    }

    get getCommandOutput(){
        return this._commandOutput;
    }
    set setCommandOutput(cmdOutput:string){
        this._commandOutput = cmdOutput;
    }

    get getCommandID(){
        return this._commandID;
    }

   private generateCommandID():number{
        return TerminalCommand._nextCommandID++;
    }
}

export interface  IState{
    cursorPosition: number,
    indexSection:number,
    dirEntryTraverseCntr:number,
    currentPath:string
}

export interface  ITabState{
    sections:IState[]
}

export interface  ITraverseResult{
    type: string,  
    result: any, 
    depth:number
}

export interface LSResult{
    type: string;  
    result: any;
}

export interface GenericResult{
    response: string;  
    result: boolean;
}