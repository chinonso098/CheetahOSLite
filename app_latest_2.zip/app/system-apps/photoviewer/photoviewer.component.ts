/* eslint-disable @angular-eslint/prefer-standalone */
import { Component, OnInit, AfterViewInit, OnDestroy, ChangeDetectorRef, ViewChild, ElementRef, Input, HostListener } from '@angular/core';
import { FileService } from 'src/app/shared/system-service/file.service';
import { BaseComponent } from 'src/app/system-base/base/base.component.interface';
import { ComponentType } from 'src/app/system-files/system.types';
import {extname, dirname} from 'path';
import { ProcessIDService } from 'src/app/shared/system-service/process.id.service';
import { Process } from 'src/app/system-files/process';
import { RunningProcessService } from 'src/app/shared/system-service/running.process.service';
import { ProcessHandlerService } from 'src/app/shared/system-service/process.handler.service';
import { FileInfo } from 'src/app/system-files/file.info';
import { AppState } from 'src/app/system-files/state/state.interface';
import { SessionManagementService } from 'src/app/shared/system-service/session.management.service';
import { Constants } from 'src/app/system-files/constants';
import * as htmlToImage from 'html-to-image';
import { TaskBarPreviewImage } from '../taskbarpreview/taskbar.preview';
import { WindowService } from 'src/app/shared/system-service/window.service';
import { CommonFunctions } from 'src/app/system-files/common.functions';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { WindowResizeInfo } from 'src/app/shared/system-component/window/windows.types';
import { Subscription } from 'rxjs';

@Component({
  selector: 'cos-photoviewer',
  templateUrl: './photoviewer.component.html',
  styleUrls: ['./photoviewer.component.css'],
  standalone:false,
  animations: [
    trigger('slideStatusAnimation1', [
      state('slideOut', style({zIndex: 0, right: '-300px' })),
      state('slideIn', style({ zIndex: 1, right: '0' })),

      transition('slideOut => slideIn', [
        animate('150ms ease-in'),
      ]),
      transition('slideIn => slideOut', [
        animate('100ms ease-out'),
      ]),
    ])
  ]
})
export class PhotoViewerComponent implements BaseComponent, OnInit, OnDestroy, AfterViewInit {

  @ViewChild('photoContainer', {static: true}) photoContainer!: ElementRef; 
  @Input() priorUId = Constants.EMPTY_STRING;

  private _fileService!:FileService;
  private _processIdService!:ProcessIDService;
  private _runningProcessService!:RunningProcessService;
  private _processHandlerService!:ProcessHandlerService;
  private _sessionManagementService!:SessionManagementService;
  private _windowService!:WindowService;

  private _maximizeWindowSub!: Subscription;
  private _minimizeWindowSub!: Subscription;
  private _windowResizeSub!: Subscription;

  readonly MIN_WIDTH_PX = 480;
  readonly MIN_HEIGHT_PX = 320;

  private _fileInfo!:FileInfo;
  private _appState!:AppState;
  private _picSrc = Constants.EMPTY_STRING;
  private _returnedPicSrc = Constants.EMPTY_STRING;
  private _checkThisDirectoryForMoreImages = true;
  private _skipOnInit = false;
  private _skipAfterInit = false;
  private currentImgIndex = 0;
  private readonly PATH_TO_IGNORE = '/AppData/StartMenu/photoviewer.url';

  readonly SECONDS_DELAY = 300;// 300ms
  readonly GALLERY_VIEW = 'gallery view';
  readonly PHOTO_VIEW = 'photo view'
  readonly BASE_64_PNG_IMG = 'data:image/png;base64';
  readonly BLOB = 'blob:http:';
  firstView = Constants.EMPTY_STRING;

  defaultView = this.GALLERY_VIEW;
  favoriteImg = `${Constants.IMAGE_BASE_PATH}photos_heart.png`;
  folderPathImg = `${Constants.IMAGE_BASE_PATH}photos_info_path.png`;
  fullScaleImg = `${Constants.IMAGE_BASE_PATH}photos_scale.png`;
  galleryImg = `${Constants.IMAGE_BASE_PATH}photos_gallery.png`;
  goBackImg =  `${Constants.IMAGE_BASE_PATH}photos_go_back.png`;
  infoImg = `${Constants.IMAGE_BASE_PATH}photos_info.png`;
  nextImg = `${Constants.IMAGE_BASE_PATH}photos_next_image.png`;
  prevImg = `${Constants.IMAGE_BASE_PATH}photos_prev_image.png`;
  photoImg =  `${Constants.IMAGE_BASE_PATH}photos_info_picture.png`;
  calendarImg =  `${Constants.IMAGE_BASE_PATH}photos_info_calendar.png`;
  scaleImg = `${Constants.IMAGE_BASE_PATH}photos_scale.png`;
  scaleInImg = `${Constants.IMAGE_BASE_PATH}photos_scale_in.png`;
  sizeImg = `${Constants.IMAGE_BASE_PATH}photos_size.png`;
  slideShowImg = `${Constants.IMAGE_BASE_PATH}photos_carousel.png`;
  srcImg =  `${Constants.IMAGE_BASE_PATH}photos_info_source.png`;
  resolutionImg = `${Constants.IMAGE_BASE_PATH}photos_resolution.png`;
  resolutionImg1 = `${Constants.IMAGE_BASE_PATH}photos_info_resolution.png`;
  timeImg =  `${Constants.IMAGE_BASE_PATH}photos_info_time.png`;
  zoomInImg = `${Constants.IMAGE_BASE_PATH}photos_zoom_in.png`;
  zoomOutImg = `${Constants.IMAGE_BASE_PATH}photos_zoom_out.png`;

  currentImg = Constants.EMPTY_STRING;
  selectedIdx = 0;

  GALLERY = 'Gallery';
  FAVORITE = 'Favorite';

  imageList:string[][] = [];
  unFilteredImageList:string[][] = [];
  imageListUrl:string[] = [];
  imageFileList:FileInfo[] = [];
  galleryOptions:string[][] = [[this.galleryImg, this.GALLERY]]; // [this.favoriteImg, this.FAVORITE]];;

  screenShotCount = 0;
  sampleCount = 0;
  otherCount = 0;

  imgDimension = Constants.EMPTY_STRING;
  imgSize = Constants.EMPTY_STRING;
  photoName = Constants.EMPTY_STRING;
  imgFilePath = Constants.EMPTY_STRING;
  fileDate:Date= new Date();

  readonly SCREEN_SHOT = 'ScreenShot';
  readonly SAMPLE = 'Sample';
  readonly OTHER = 'Other';
  sortBy = Constants.EMPTY_STRING;
  dash = Constants.DASH;
  imgData = '72 dpi - 24 bit';
  slideState = 'slideOut';

  zoomLevel: number = 0.8;
  zoomStep: number = 0.1;
  minZoom: number = 0.25;
  maxZoom: number = 4;
  zoomRefValue:number = 0.8;

  transformOrigin: string = 'center center'; // default
  // zoomTransform: string = 'scale(1)';
  transformStyle: string = 'scale(0.8) translate(0px, 0px)';

  // panning state
  isPanning: boolean = false;
  startX: number = 0;
  startY: number = 0;
  translateX: number = 0;
  translateY: number = 0;
  lastTranslateX: number = 0;
  lastTranslateY: number = 0;

  private readonly defaultPath = '/Users/Pictures';
  private readonly defaultImg = '/Users/Pictures/Samples/no_img.jpeg';
  private readonly samplePath = '/Users/Pictures/Sample';
  private readonly screenShotPath = '/Users/Pictures/Screen-Shots';

  isOpen = false;
  isMouseMoveActive = false;
  showImageSlide = false;
  showImageInfo = false;

  currentZoomValue = '80%';
  zoomOptions = [
    { value: 4, label: '400%'},
    { value: 3, label: '300%'},
    { value: 2, label: '200%'},
    { value: 1, label: '100%'},
    { value: 0.75, label: '75%'},
    { value: 0.5, label: '50%'},
    { value: 0.25, label: '25%'},
  ];

  name= 'photoviewer';
  hasWindow = true;
  icon = `${Constants.IMAGE_BASE_PATH}photoviewer.png`;
  isMaximizable = false;
  processId = 0;
  type = ComponentType.System;
  displayName = 'PhotoViewer';

  constructor(fileService:FileService, processIdService:ProcessIDService, runningProcessService:RunningProcessService, 
              triggerProcessService:ProcessHandlerService,  sessionManagementService: SessionManagementService, private changeDetectorRef: ChangeDetectorRef,
              windowService:WindowService) { 
    this._fileService = fileService
    this._processIdService = processIdService;
    this._processHandlerService = triggerProcessService;
    this._sessionManagementService = sessionManagementService;
    this._runningProcessService = runningProcessService;
    this._windowService = windowService;

    this._maximizeWindowSub = this._windowService.maximizeProcessWindowNotify.subscribe(() =>{this.maximizeWindow()});
    this._minimizeWindowSub = this._windowService.minimizeProcessWindowNotify.subscribe(() =>{this.minimizeWindow()});
    this._windowResizeSub = this._windowService.resizeProcessWindowNotify.subscribe((info: WindowResizeInfo) => {
      if(info.pId !== this.processId) return;
      if(info.widthPx < this.MIN_WIDTH_PX || info.heightPx < this.MIN_HEIGHT_PX) return;
      this.onWindowResize();
    });
    this.processId = this._processIdService.getNewProcessId();
    this._runningProcessService.addProcess(this.getComponentDetail());
  }

  async ngOnInit():Promise<void> {
    this.retrievePastSessionData();

    if(this._skipOnInit) return;

    //this._fileInfo = this._processHandlerService.getLastProcessTrigger();
    await this.getImageData(this._fileInfo);
    this.setFirstView(this._fileInfo);

    if(this._fileInfo)
        this.imageFileList.push(this._fileInfo);

    //base64 imgs are generated screenshots, opened  immediately after creation
    if(this.checkIfImgIsBase64(this._fileInfo.getContentPath)){
      this.currentImg = this._fileInfo.getContentPath;
      this._skipAfterInit = true;
      this.defaultView = this.PHOTO_VIEW;
      return;
    }

    if(this.checkForBlobURI(this._fileInfo.getContentPath)){
      this.currentImg = this._fileInfo.getContentPath;
      this.defaultView = this.PHOTO_VIEW;
      return;
    }
  } 

  async ngAfterViewInit():Promise<void> {
    await CommonFunctions.sleep(this.SECONDS_DELAY);
    await this.captureComponentImg();
    this.updateImg();

    if(this._skipAfterInit) return;

    this.setFirstView(this._fileInfo);
    this._picSrc = this.getPictureSrc(this._fileInfo);
    if(this._picSrc === this.PATH_TO_IGNORE 
      || (this._picSrc === Constants.EMPTY_STRING && this._returnedPicSrc === Constants.EMPTY_STRING)){
      await this.getAllPicturesInthePicturesFolder(this.defaultPath);
      this.defaultView = this.GALLERY_VIEW;
      return;
    }

    if(this._checkThisDirectoryForMoreImages){
      await this.getAllPicturesIntheCurrentPath();

      const wereMoreImagesFound = (this.imageList.length > 0);
      if(wereMoreImagesFound)
        this.currentImg = this.imageList[0][0];
      else{ 
        if(this._fileInfo.getContentPath !== Constants.EMPTY_STRING)
          this.currentImg =  this._fileInfo.getContentPath;
        else
          this.currentImg = await this._fileService.getFileAsBlobAsync(this.defaultImg);
      }

      const appData = (wereMoreImagesFound)? this.imageListUrl : this._fileInfo.getCurrentPath;
      this.storeAppState(appData);
    }else{
      const currentImg = await this._fileService.getFileAsBlobAsync(this.defaultImg);
      this.currentImg = currentImg;
    }
  }

  ngOnDestroy(): void {
    this._maximizeWindowSub?.unsubscribe();
    this._minimizeWindowSub?.unsubscribe();
    this._windowResizeSub?.unsubscribe();
  }

  setFirstView(file:FileInfo):void{

    if(this.firstView !== Constants.EMPTY_STRING) return;

    if(!file 
      || (file.getContentPath === Constants.EMPTY_STRING && file.getCurrentPath === Constants.EMPTY_STRING)
      || (file.getCurrentPath === this.PATH_TO_IGNORE && file.getContentPath === Constants.EMPTY_STRING)){

      this.firstView = this.GALLERY_VIEW;
      return;
    }

    this.firstView = this.PHOTO_VIEW;
  }

  async getImageData(file:FileInfo): Promise<void>{
    if(!file) return;

    await new Promise<void>((resolve) => {
      const img = new Image();
      img.src = file.getContentPath;
      img.onload = () => {
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        this.imgDimension = `${width} x ${height}`;
        this.imgSize = `${file.getSize} ${file.getFileSizeUnit}`;
        this.photoName = file.getFileName;
        this.imgFilePath = file.getCurrentPath;
        this.fileDate = file.getDateAccessed;

        resolve();
      };
      img.onerror = (err) => {
        console.error("Failed to load image", err);
        resolve(); // Still resolve to prevent blocking
      };
    });
  }

  async captureComponentImg():Promise<void>{  
    await CommonFunctions.captureComponentImgAsync(this.photoContainer, this.processId, this.name, this.icon, this._windowService);
  }

  updateImg():void{
    this.scaleImg = (this.zoomLevel < 1)? this.scaleInImg : this.fullScaleImg;
  }

  onKeyDown(evt:KeyboardEvent):void{
    if(evt.key == "ArrowLeft"){
      if((this.currentImgIndex >= 0)){
        this.currentImg = this.imageList[this.currentImgIndex--][0];

        if(this.currentImgIndex < 0){
          this.currentImgIndex = this.imageList.length - 1;
        }
      }      
    }

    if(evt.key == "ArrowRight"){
      if(this.currentImgIndex <= this.imageList.length - 1){
        this.currentImg = this.imageList[this.currentImgIndex++][0];

        if(this.currentImgIndex > this.imageList.length -1){
          this.currentImgIndex = 0;
        }
      }
    }
  }

  // Handle mouse wheel zoom
  onWheel(evt: WheelEvent): void {
    evt.preventDefault();
    if (evt.deltaY < 0) {
      this.zoomIn();
    } else {
      this.zoomOut();
    }
    this.updateImg();
  }

  zoomIn(): void {
    this.zoomLevel = Math.min(this.zoomLevel + this.zoomStep, this.maxZoom);
    this.currentZoomValue = `${(this.zoomLevel * 100).toFixed(0)}%`;
    this.updateTransform();
    this.updateCursor();
    this.updateImg();
  }

  zoomOut(): void {
    this.zoomLevel = Math.max(this.zoomLevel - this.zoomStep, this.minZoom);
    this.currentZoomValue = `${(this.zoomLevel * 100).toFixed(0)}%`;
    this.updateTransform();
    this.updateCursor();
    this.updateImg();
  }

  updateCursor(): void {
    const img = document.querySelector('.photo-viewer img') as HTMLElement;
    img.style.cursor = this.zoomLevel > 1 ? 'zoom-out' : 'zoom-in';
  }
  
  onMouseMove(evt: MouseEvent): void {
    if(!this.isMouseMoveActive) return;

    const container = evt.currentTarget as HTMLElement;
    const rect = container.getBoundingClientRect();
  
    // Get mouse position as percentage within the container
    const x = ((evt.clientX - rect.left) / rect.width) * 100;
    const y = ((evt.clientY - rect.top) / rect.height) * 100;
  
    // Update transform origin dynamically
    this.transformOrigin = `${x}% ${y}%`;
  }

  startPan(evt: MouseEvent): void {
    evt.stopPropagation();

    if (this.zoomLevel <= 1) return; // only pan when zoomed in

    this.isPanning = true;
    this.startX = evt.clientX;
    this.startY = evt.clientY;
    this.lastTranslateX = this.translateX;
    this.lastTranslateY = this.translateY;
    (evt.currentTarget as HTMLElement).style.cursor = 'grabbing';
  }
  
  pan(evt: MouseEvent): void {
    evt.stopPropagation();

    if (!this.isPanning) return;
  
    const deltaX = evt.clientX - this.startX;
    const deltaY = evt.clientY - this.startY;
  
    this.translateX = this.lastTranslateX + deltaX;
    this.translateY = this.lastTranslateY + deltaY;

    //this.applyPanBoundaries(evt.currentTarget as HTMLElement);
    this.updateTransform();
  }
  
  endPan(): void {
    this.isPanning = false;
    const img = document.querySelector('.photo-viewer img') as HTMLElement;
    if (img) img.style.cursor = this.zoomLevel > 1 ? 'grab' : 'zoom-in';
  }
  
  updateTransform(): void {
    this.transformStyle = `scale(${this.zoomLevel}) translate(${this.translateX}px, ${this.translateY}px)`;
  }

  applyPanBoundaries(container: HTMLElement): void {
    const rect = container.getBoundingClientRect();
    const baseHeight = 550; // your default image height
    const baseWidth = rect.width * (baseHeight / rect.height); // approximate width based on container
  
    // actual image size at current zoom
    const zoomedWidth = baseWidth * this.zoomLevel;
    const zoomedHeight = baseHeight * this.zoomLevel;
  
    // maximum allowed translation (so part of image always visible)
    const maxX = (zoomedWidth - rect.width) / 2;
    const maxY = (zoomedHeight - rect.height) / 2;
  
    // clamp translation values
    this.translateX = Math.max(-maxX, Math.min(maxX, this.translateX));
    this.translateY = Math.max(-maxY, Math.min(maxY, this.translateY));
  }

   //Double-click resets everything
   resetView(): void {
    this.zoomLevel = 1;
    this.currentZoomValue = '100%';
    this.translateX = 0;
    this.translateY = 0;
    this.transformOrigin = 'center center';
    this.updateTransform();
  }

  //Fit-to-screen button resets and adjusts for container
  fitToScreen(): void {
    this.resetView();
  }

  showImageCarousel():void{
    this.showImageSlide = !this.showImageSlide;
  }

  showImageInfoPane():void{
    this.showImageInfo = !this.showImageInfo;
    this.slideState = (this.showImageInfo)? 'slideIn' : 'slideOut';
  }

  goBackToGallery(): void {
    this.defaultView = this.GALLERY_VIEW;
  }

  onZoomOptionSelect( evt:any):void{
    evt.stopPropagation();
  }

  toggleDropdown(evt?:MouseEvent):void{
    evt?.stopPropagation();
    this.isOpen = !this.isOpen;
  }

  handleZoomSelection(option: { value: number, label: string },   evt:MouseEvent):void{

  }

  onZoomSliderChange(event: Event):void{
    const inputElement = event.target as HTMLInputElement;
    const slideValue = Number(inputElement.value);
    const zoomValue = (slideValue/100);
    if(zoomValue > this.zoomRefValue){
      this.zoomRefValue = zoomValue;
      this.zoomLevel = Math.min(this.zoomLevel + zoomValue, this.maxZoom);
    }else{
      this.zoomRefValue = zoomValue;
      this.zoomLevel = Math.max(this.zoomLevel - this.zoomStep, this.minZoom);
    }

    this.currentZoomValue = `${(this.zoomLevel * 100).toFixed(0)}%`;
    this.updateTransform();
    this.updateCursor();
  }

  async onClick(id:number): Promise<void>{
    this.currentImg = this.imageList[id][0];
    this.currentImgIndex = id;

    const file = this.imageFileList[id];
    await this.getImageData(file)
  }

  focusHere(evt:MouseEvent):void{
    evt.preventDefault();
    evt.stopPropagation();

    const photoCntnr= document.getElementById('photoCntnr') as HTMLElement;
    if(photoCntnr){
      photoCntnr?.focus();
    }

    this.focusWindow();
  }

 silenceCtxEvt(evt?:MouseEvent):void{
    // Right-clicking anywhere on the App (outside the header row,
    // which opens our own column menu) should NOT pop the desktop's context
    // menu.
    //  - preventDefault(): suppress the native browser context menu.
    //  - stopPropagation(): keep the event from reaching the desktop root.
    evt?.preventDefault();
    evt?.stopPropagation();
  }

  async getAllPicturesIntheCurrentPath():Promise<void>{
    let imgCount = 0;

    // if stuff was returned from session, then use it.
    if(this.imageListUrl.length === 0  && (this._fileInfo)){
      const dirPath = dirname(this._fileInfo.getCurrentPath);
      const entries:string[] = await this._fileService.readDirectory(dirPath);

      for(const entry of entries){
        if(Constants.IMAGE_FILE_EXTENSIONS.includes(extname(entry))){
          const entryPath = `${dirPath}/${entry}`;
          imgCount = imgCount +  1;

          if(entryPath !== this._fileInfo.getCurrentPath){
            const file =  await this._fileService.getFileInfo(`${dirPath}/${entry}`);
            if(file){
              this.imageList.push([file.getContentPath,  this.getSrcName(this._fileInfo.getCurrentPath)]);
              this.imageListUrl.push(file.getCurrentPath);
              this.imageFileList.push(file);
            }
          }
        }
      }

      if(imgCount > 1){
        this.imageList.unshift([this._fileInfo.getContentPath, this.getSrcName(this._fileInfo.getCurrentPath)]);
        return;
      }
    }else if(this.imageListUrl.length > 0){
      for(const entry of this.imageListUrl){
        const img = await this._fileService.getFileAsBlobAsync(entry);
        this.imageList.push([img, this.getSrcName(entry)]);
      }
      return;
    }else if(this._returnedPicSrc !== Constants.EMPTY_STRING){
      this._fileInfo =  await this._fileService.getFileInfo(this._returnedPicSrc);
    }
  }

  async getAllPicturesInthePicturesFolder(path:string):Promise<void>{
    const entries:string[] = await this._fileService.readDirectory(path);
    for(const entry of entries){
      const entryPath = `${path}/${entry}`;
      const stat = await this._fileService.getStatAsync(entryPath);

      if(stat.isDirectory){
        await this.getAllPicturesInthePicturesFolder(entryPath);
      }else{
        const file =  await this._fileService.getFileInfo(entryPath);
        if(file && Constants.IMAGE_FILE_EXTENSIONS.includes(file.getFileExtension) && entryPath !== this.defaultImg){

          if(entryPath.includes(this.samplePath))
            this.sampleCount++;

          if(entryPath.includes(this.screenShotPath))
            this.screenShotCount++;

          this.imageList.push([file.getContentPath, this.getSrcName(entryPath) ]);
          this.imageFileList.push(file);
        }
      }
    }

    this.otherCount = (this.imageList.length - this.sampleCount - this.screenShotCount);
  }

  getSrcName(path:string):string{

    if(path.includes(this.samplePath))
      return 'Sample';

    if(path.includes(this.screenShotPath))
      return 'ScreenShot';

    return 'Other';
  }

  async handleGalleryOptionSelection(selection:string, idx:number, evt:MouseEvent, view:string): Promise<void>{

  }

  handleSortBy(selection:string):void{
    this.sortBy = selection;
    
    if(this.unFilteredImageList.length === 0)
      this.unFilteredImageList.push(...this.imageList);

    if(this.unFilteredImageList.length !== this.imageList.length){
      this.imageList = [];
      this.imageList.push(...this.unFilteredImageList);
    }

    this.imageList = this.imageList.filter( x => x[1] === selection);
  }

  async handlePictureSelection(img:string, evt:MouseEvent): Promise<void>{
    evt.stopPropagation();

    this.currentImg = img;
    this.defaultView = this.PHOTO_VIEW;

    const imgIdx = this.imageList.findIndex(x => x[0] === img);
    const imgFile = this.imageFileList[imgIdx + 1];
    await this.getImageData(imgFile);
  }

  @HostListener('document:click')
  onOutsideClick(): void {
    this.isOpen = false;
  }

  focusWindow(evt?:MouseEvent):void{
    evt?.stopPropagation();
    this.onOutsideClick();

    if(this._windowService.getProcessWindowIDWithHighestZIndex() === this.processId) return;
    this._windowService.focusOnCurrentProcessWindowNotify.next(this.processId);
  }

  getPictureSrc(file:FileInfo):string{   
    if(!file) return Constants.EMPTY_STRING;

    const { getCurrentPath, getContentPath } = file;
    if(this.checkIfImgIsBase64(getContentPath)){
      this._checkThisDirectoryForMoreImages = false;
      return getContentPath;
    }

    if (getCurrentPath === this.PATH_TO_IGNORE && getContentPath === Constants.EMPTY_STRING) {
      return getCurrentPath;
    }

    if((getCurrentPath !== Constants.EMPTY_STRING && getContentPath !== Constants.EMPTY_STRING)
      || (getCurrentPath !== Constants.EMPTY_STRING && getContentPath === Constants.EMPTY_STRING)){
      return getCurrentPath;
    }

    if (getCurrentPath === Constants.EMPTY_STRING && getContentPath === Constants.EMPTY_STRING) {
      return this._picSrc;
    }

    return Constants.EMPTY_STRING;
  }

  checkIfImgIsBase64(getContentPath:string):boolean{
    if(getContentPath.substring(0, 21) === this.BASE_64_PNG_IMG)
      return true;

    return false
  }

  checkForBlobURI(getContentPath:string):boolean{
    if(getContentPath.substring(0, 10) === this.BLOB)
      return true;

    return false
  }

  storeAppState(app_data:unknown):void{
    const uId = `${this.name}-${this.processId}`;
    this._appState = {
      pId: this.processId,
      appData: app_data,
      appName: this.name,
      uId: uId,
      window: {appName:'', pId:0, leftPx:0, topPx:0, heightPx:0, widthPx:0, zIndex:0, isVisible:true}
    }
    this._sessionManagementService.addAppSession(uId, this._appState);
  }

  retrievePastSessionData():void{
    const appSessionData = this._sessionManagementService.getAppSession(this.priorUId);
    if(appSessionData !== null && appSessionData.appData !== Constants.EMPTY_STRING){
        this._skipOnInit = true;

        if(typeof appSessionData.appData === 'string')
          this._returnedPicSrc = appSessionData.appData as string; 
        else
          this.imageListUrl = appSessionData.appData as string[];
    }
  }

  maximizeWindow():void{
    const uId = `${this.name}-${this.processId}`;
    const evtOriginator = this._runningProcessService.getEventOriginator();

    if(uId === evtOriginator){
      this._runningProcessService.removeEventOriginator();
      this.onWindowResize();
    }
  }

  minimizeWindow():void{
    const uId = `${this.name}-${this.processId}`;
    const evtOriginator = this._runningProcessService.getEventOriginator();

    if(uId === evtOriginator){
      this._runningProcessService.removeEventOriginator();
      this.onWindowResize();
    }
  }

  onWindowResize():void{
    // CSS flex chain owns layout; just strip any leftover inline px that older
    // imperative code may have written to the photo container.
    const el = this.photoContainer?.nativeElement as HTMLElement | undefined;
    if(!el) return;
    el.style.removeProperty('height');
    el.style.removeProperty('width');
  }

  private getComponentDetail():Process{
    this._fileInfo = this._processHandlerService.getLastProcessTrigger(this.name);
    return new Process(this.processId, this.name, this.icon, this.hasWindow, this.type, this._fileInfo)
  }

}

